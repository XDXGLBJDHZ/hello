create
    definer = root@localhost procedure findall()
BEGIN
	#Routine body goes here...
SELECT * FROM `user`;
END;

