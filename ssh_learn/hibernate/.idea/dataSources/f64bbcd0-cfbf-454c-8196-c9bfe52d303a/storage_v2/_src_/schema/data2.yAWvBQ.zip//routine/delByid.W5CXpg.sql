create
    definer = root@localhost procedure delByid(IN p1 int)
BEGIN
	#Routine body goes here...
DECLARE v1 INT;
SET v1= p1;
DELETE FROM `user` WHERE id = v1;
END;

