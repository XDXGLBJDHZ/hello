create
    definer = root@localhost procedure addAdmin(IN p1 varchar(50), IN p2 varchar(50))
BEGIN
	#Routine body goes here...
DECLARE v1 VARCHAR(50);
DECLARE v2 VARCHAR(50);
SET v1=p1;
SET v2=p2;
INSERT INTO user(username,password) VALUES(v1,v2);
END;

