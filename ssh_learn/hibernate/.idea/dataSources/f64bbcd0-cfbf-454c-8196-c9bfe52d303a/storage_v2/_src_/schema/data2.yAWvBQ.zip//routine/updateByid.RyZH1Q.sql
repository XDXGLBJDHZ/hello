create
    definer = root@localhost procedure updateByid(IN usernamee varchar(50), IN passwordd varchar(50), IN idd int)
BEGIN
	#Routine body goes here...
DECLARE v1 VARCHAR(50);
DECLARE v2 VARCHAR(50);
DECLARE v3 INT;
SET v1=usernamee;
SET v2=passwordd;
SET v3=idd;
UPDATE user SET username=v1 ,password=v2 WHERE  id=v3;  
END;

