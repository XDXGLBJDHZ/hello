create
    definer = root@localhost procedure findByid(IN p1 int)
BEGIN
	#Routine body goes here...
DECLARE v1 int;
SET v1 =p1;
SELECT * FROM `user` WHERE id=v1;
END;

